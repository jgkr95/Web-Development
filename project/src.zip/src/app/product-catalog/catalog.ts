import { Products } from './products';
    export const PRODUCTS: Products[]= [{
            "title": "Tops",
            "description": "Natural waves with a red top and red lipstick is a fashion win ",
            "image": "1.jpeg",
            "quantity":"10",
            "price" : 1699
        },
        {
            "title": "Shoes",
            "description": "Men’s casual shoes. Discover this and many more items in Bershka with new products every week",
            "image": "2.jpeg",
            "quantity":"20",
            "price" : 1999

        },
        {
            "title": "MAC",
            "description": "There are thousands of cosmetic brands and natural beauty products available on the market these days. Customers are spoiled for choice when it comes to",
            "image": "3.jpeg",
            "quantity":"30",
            "price" : 999
        },
        {
            "title": "Bags",
            "description": "Michael Kors Handbags", 
            "image": "4.jpeg",
            "quantity":"40",
            "price" : 16999
        },
        {
            "title": "Hands Bags",
            "description": "Luios Vuitton bags",
            "image": "5.jpg",
            "quantity":"4",
            "price" : 15000
        },
        {
            "title": "Suits",
            "description": "ethinc wear!!",
            "image": "6.jpg",
            "quantity":"40",
            "price" : 16999
        },
        {
            "title": "Victorias",
            "description": "Victoria's Secret has some of the most gorgeous packaging on their fragrances, and Scandalous is no exception. As soon as I laid my eyes on this fabulous bottle, I knew I was going to love it",
            "image": "7.jpg",
            "quantity":"40",
            "price" : 16999
        },
        {
            "title": "Shirts",
            "description": "Priory the formal shirts for men were only carried for official wear. However, now they are worn for social events as well.",
            "image": "8.jpg",
            "quantity":"40",
            "price" : 16999
        },
        {
            "title": "Jewellery",
            "description": "Antique Gold jewellery is evergreen and no other models can take its place. Here are the 9 best antic gold jewellery designs for Women and girls.",
            "image": "9.jpg",
            "quantity":"40",
            "price" : 16999
        },
        {
            "title": "Jeans",
            "description": "Zara Addiction op Instagram",
            "image": "10.jpg",
            "quantity":"40",
            "price" : 16999
        },
        {
            "title": "Apple ihone",
            "description": "Apple iphone",
            "image": "11.jpg",
            "quantity":"40",
            "price" : 16999
        },
        {
            "title": "Laptop",
            "description": "The Surface Laptop 2 is a well-rounded stunner.",
            "image": "12.jpg",
            "quantity":"40",
            "price" : 16999
        },

    ]


