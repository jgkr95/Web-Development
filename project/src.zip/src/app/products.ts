export class Products{
    title: string;
    description:string;
    image:string;
    quantity:string;
    price: number;
}